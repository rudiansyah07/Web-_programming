<html>
		Anak ayam turun 10
	<table>

		</tr>
		<tr>
			<td><?php for ($i=1; $i <= 10  ; $i++) { echo "Anak ayam turun " .$i."<br>";} ?></td>
			<td><?php for ($x=0; $x <= 9 ; $x++) { echo ", mati satu tinggal ".$x."<br>";} ?></td>
		</tr>

		
	</table>
		mati satu tinggal induknya
</html>




